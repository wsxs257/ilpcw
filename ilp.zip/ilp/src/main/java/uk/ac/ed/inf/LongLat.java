package uk.ac.ed.inf;
import java.lang.Math;
import java.util.InputMismatchException;


public class LongLat implements Comparable<LongLat>{
    double longitude;
    double latitude;
    LongLat parent;
    double g_cost = 0;
    double heuristic;
    int angle;
    double F = g_cost+heuristic;



    LongLat (double longitude,double latitude) {
        this.latitude = latitude;
        this.longitude = longitude;
    }

    LongLat (double longitude,double latitude,LongLat parent,double g_cost,double heuristic){
        this.longitude = longitude;
        this.latitude = latitude;
        this.parent = parent;
        this.g_cost = g_cost;
        this.heuristic = heuristic;
    }

    /***
     *
     * @return bool
     */
    public boolean isConfined(){
        if (-3.192473<longitude&&longitude<-3.184319&&latitude< 55.946233&&latitude>55.942617){
            return true;
        }else {
            return false;
        }
    }

    /***
     * TODO calculate the distance between the drone and one place
     * @param longLat
     * @return double
     */
    public double distanceTo(LongLat longLat) {
        double distance = Math.sqrt((longitude-longLat.longitude)*(longitude-longLat.longitude)+(latitude-longLat.latitude)*(latitude-longLat.latitude));
        return distance;
    }

    public int costOfmoves(LongLat longLat){
        double distance = distanceTo(longLat);
        int moves = (int)Math. round(distance/0.00015);
        return moves;
    }

    /**
     * TODO check if the drone is close to the other place (distance<0.00015)
     * @param longLat
     * @return bool
     */
    public boolean closeTo(LongLat longLat){
        double distance = distanceTo(longLat);
        if (distance<0.00015){
            return true;
        }else {
            return false;
        }
    }

    /**
     * @// TODO: generate the next position of the drone
     * @param angle
     * @return longlat
     * @throws IllegalArgumentException
     */
    public LongLat nextPosition(int angle){
        LongLat longLat = new LongLat(longitude,latitude);
        if (angle>=0&&angle<=360){
            double radians = Math.toRadians(angle);
            longLat.longitude = longitude + 0.00015*Math.cos(radians);
            longLat.latitude = latitude + 0.00015*Math.sin(radians);
            return longLat;
        }else if (angle == -999){
            return longLat;
        }else{
            throw new IllegalArgumentException("wrong angle input!!");
        }
    }


    public double getFcost(){
        return g_cost+heuristic;
    }


    @Override
    public int compareTo(LongLat o) {
        if(o == null)return -1;
        if(g_cost+heuristic>o.g_cost+o.heuristic)
            return 1;
        else if(g_cost+heuristic<o.g_cost+o.heuristic)return -1;
        return 0;
    }


    @Override
    public boolean equals(Object obj)
    {
        if (obj == null) return false;
        if (obj instanceof LongLat)
        {
            LongLat longLat = (LongLat) obj;
            return longitude == longLat.longitude && latitude == longLat.latitude;
        }
        return false;
    }
}
