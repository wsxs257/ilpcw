package uk.ac.ed.inf;

import java.awt.*;
import java.awt.geom.Line2D;
import java.lang.reflect.Array;
import java.sql.SQLException;
import java.util.*;
import java.lang.Math;
import java.util.List;

import com.mapbox.geojson.*;
import com.mapbox.geojson.Point;
import org.apache.derby.client.am.SqlException;

import javax.sound.sampled.Line;

public class DroneFlightPath {
    String webPort;
    String dataPort;
    String date;
    int moves = 0;

    LongLat ApptonTower = new LongLat(-3.186874, 55.944494);
    LongLat drone = new LongLat(-3.186874, 55.944494);
//    Node current = new Node(-3.186874, 55.944494);
    Buildings noFlyZone = new Buildings("9898");

    LongLat landmark1 = new LongLat(-3.1910300,55.9452978);
    LongLat landmark2 = new LongLat(-3.1912800,55.943937);
    LongLat landmark3 = new LongLat(-3.18781,55.94447);
    LongLat landmark4 = new LongLat(-3.18796,55.94477);
    LongLat landmark5 = new LongLat(-3.18840,55.94510);
    LongLat landmark6 = new LongLat(-3.1893300,55.9455678);

    DroneFlightPath(String webPort, String dataPort, String date) {
        this.webPort = webPort;
        this.dataPort = dataPort;
        this.date = date;
    }


    public double getLng(String threeWord) {
        String[] wordList = threeWord.split("[.]");
        String webURL = "http://localhost:" + webPort + "/words/" + wordList[0] + "/" + wordList[1] + "/" + wordList[2] + "/details.json";
        Words words = new Words(webURL);
//        double lng = words.getLng();
        return words.getLng();
    }


    public double getLat(String threeWord) {
        String[] wordList = threeWord.split("[.]");
        String webURL = "http://localhost:" + webPort + "/words/" + wordList[0] + "/" + wordList[1] + "/" + wordList[2] + "/details.json";
        Words words = new Words(webURL);
        double lat = words.getLat();
        return lat;
    }


    //TODO get the location where is the restaurant
    public ArrayList<LongLat> getDroneFlightPathList() throws SQLException {
        ArrayList<LongLat> path = new ArrayList<>();
        Ordetails ordetails = new Ordetails();
        ArrayList<Ordetails> details = ordetails.makeDetailsList(date, dataPort, webPort);
        details.sort(new costSorter());
        for (Ordetails detail : details) {
            ArrayList<String> deliverFrom = detail.deliverFrom;
            for (String deliverfrom : deliverFrom) {
                double lng = getLng(deliverfrom);
                double lat = getLat(deliverfrom);
                System.out.println(lng);
                System.out.println(lat);
                System.out.println("To");
                LongLat longLat = new LongLat(lng, lat);
                path.add(longLat);
            }
            double lng = getLng(detail.deliverTo);
            double lat = getLat(detail.deliverTo);
            System.out.println(lng);
            System.out.println(lat);
            System.out.println("To");
            LongLat longLat = new LongLat(lng, lat);
            path.add(longLat);
        }
        return path;
    }


    public int calAnagle(LongLat start, LongLat end) {
        if (end.longitude > start.longitude && end.latitude == start.latitude) {
            return 0;
        } else if (end.longitude < start.longitude && end.latitude == start.latitude) {
            return 180;
        } else if (end.longitude == start.longitude && end.latitude > start.latitude) {
            return 90;
        } else if (end.longitude == start.longitude && end.latitude < start.latitude) {
            return 270;
        }
        int tan = (int) Math.round(Math.atan(Math.abs((end.latitude - start.latitude) / (end.longitude - start.longitude))) * 180 / Math.PI);
        if (tan % 10 >= 5) {
            tan = tan / 10 * 10 + 10;
        } else {
            tan = tan / 10 * 10;
        }
        if (end.longitude > start.longitude && end.latitude > start.latitude)//第一象限
        {
            return tan;
        } else if (end.longitude < start.longitude && end.latitude > start.latitude)//第二象限
        {
            return 180 - tan;
        } else if (end.longitude < start.longitude && end.latitude < start.latitude)//第三象限
        {
            return 180 + tan;

        } else {
            return 360 - tan;
        }
    }

    /**
     * @param drone
     * @param destination
     * @return
     */
    public boolean checkInNoFlyZone(LongLat drone, LongLat destination) {
        Line2D flightpath = new Line2D.Double();
        flightpath.setLine(drone.longitude, drone.latitude, destination.longitude, destination.latitude);
        ArrayList<Line2D> NoFlyZone = noFlyZone.getLine2DNoFlyZone();
        for (Line2D noflyline : NoFlyZone) {
            if (noflyline.intersectsLine(flightpath)) {
                return true;
            } else {

                continue;
            }
        }
        return false;
    }




    //TODO line it with the deliverTo location check if it pass no-fly-zone
    public String getFlyPath() throws SQLException {
        ArrayList<LongLat> path = getDroneFlightPathList();
        ArrayList<Point> RealFlightpath = new ArrayList<>();
        Point StartLocation = Point.fromLngLat(ApptonTower.longitude, ApptonTower.latitude);
        RealFlightpath.add(StartLocation);
        for (LongLat station : path) {
            Line2D directFlightpath = new Line2D.Double();
            directFlightpath.setLine(drone.longitude, drone.latitude, station.longitude, station.latitude);
            LongLat landmark = noFlyZone.getClosedLandMark(drone);
            if (checkInNoFlyZone(drone, station) == true) {
                while (drone.closeTo(landmark) == false) {
                    drone = drone.nextPosition(calAnagle(drone, landmark));
                    moves = moves - 1;
                    Point point = Point.fromLngLat(drone.longitude, drone.latitude);
                    RealFlightpath.add(point);
                }
                while (drone.closeTo(station) == false) {
                    drone = drone.nextPosition(calAnagle(drone, station));
                    moves = moves - 1;
                    Point point = Point.fromLngLat(drone.longitude, drone.latitude);
                    RealFlightpath.add(point);
                }
            } else {
                while (drone.closeTo(station) == false) {
                    drone = drone.nextPosition(calAnagle(drone, station));
                    moves = moves - 1;
                    Point point = Point.fromLngLat(drone.longitude, drone.latitude);
                    RealFlightpath.add(point);
                }
            }
        }
        while (drone.closeTo(ApptonTower) == false) {
            drone = drone.nextPosition(calAnagle(drone, ApptonTower));
            moves = moves - 1;
            Point point = Point.fromLngLat(drone.longitude, drone.latitude);
            RealFlightpath.add(point);
        }
        System.out.println(moves);
        LineString line = LineString.fromLngLats(RealFlightpath);
        Geometry geometry = (Geometry) line;
        Feature feature = Feature.fromGeometry(geometry);
        FeatureCollection featureCollection = FeatureCollection.fromFeature(feature);
        String jsonString = featureCollection.toJson();
        return jsonString;
    }


//    MinHeap<LongLat> OpenList = new MinHeap<LongLat>();
    MinHeap OpenListHeap = new MinHeap();

    PriorityQueue<LongLat> OpenList=new PriorityQueue<LongLat>(new Comparator<LongLat>() {
        @Override
        public int compare(LongLat o1, LongLat o2) {
            if (o1 == null && o2 == null) return -1;
            if (o1.g_cost + o1.heuristic > o2.g_cost + o2.heuristic)
                return 1;
            else if (o1.g_cost + o1.heuristic < o2.g_cost + o2.heuristic) return -1;
            return 0;
            }
        });

    ArrayList<LongLat> CloseList = new ArrayList<LongLat>();

    private boolean isCoordInClose(LongLat longLat) {
        return longLat != null && isCoordInClose(longLat.longitude, longLat.latitude);
    }


    private boolean isCoordInClose(double longitude, double latitude) {
        if (CloseList.isEmpty()) return false;
        for (LongLat longLat : CloseList) {
            if (longLat.longitude == longitude && longLat.latitude == latitude) {
                return true;
            }
        }
        return false;
    }

    private boolean canAddNodeToOpen(LongLat current,LongLat longLat) {
        // 是否在地图中
        if (longLat.isConfined() == false) return false;
        // 判断是否是不可通过的结点
        if (checkInNoFlyZone(current, longLat) == true) return false;
        // 判断结点是否存在close表
        if (isCoordInClose(longLat)) return false;
        return true;
    }

    private LongLat findNodeInOpen(LongLat longLat) {
        if (longLat == null || OpenList.isEmpty()) return null;
        for (LongLat longLat1 : OpenList) {
            if (longLat.equals(longLat1)) {
                return longLat1;
            }
        }
        return null;
    }

    private void getNeiborghOne(int angle,LongLat current,LongLat station){
        ArrayList<Integer> childAngleList = new ArrayList<>();
        int init = 0;
        while (init<=90){
            childAngleList.add(init);
            init = init + 20;
        }
        childAngleList.add(angle);
        childAngleList.add(angle+90);
        childAngleList.add(angle+180);
        childAngleList.add(angle+270);
        childAngleList.add(0);
        childAngleList.add(90);
        childAngleList.add(180);
        childAngleList.add(360);
        for (int inputAngle :childAngleList){
            LongLat neibourgh = current.nextPosition(inputAngle);
            if (canAddNodeToOpen(current,neibourgh)) {
                double g_cost = current.g_cost+0.00015;
                LongLat child = findNodeInOpen(neibourgh);
                if(child == null){
                    double heuristic = neibourgh.distanceTo(station);

                    if (neibourgh.closeTo(station)){
                        child = new LongLat(station.longitude,station.latitude);
                        child.parent = current;
                        child.g_cost = g_cost;
                        child.heuristic = heuristic;
                        OpenList.add(child);
                    }else {
                        child = new LongLat(neibourgh.longitude,neibourgh.latitude,current,g_cost,heuristic);
                        child.angle = inputAngle;

                        OpenList.add(child);
                    }
                }
                else if(child.g_cost>g_cost){
                    child.g_cost = g_cost;
                    child.parent = current;
                    OpenList.add(child);
                }
            }
        }
    }

    private void getNeiborghTwo(int angle,LongLat current,LongLat station){
        ArrayList<Integer> childAngleList = new ArrayList<>();
        int init = 90;
        while (init<=180){
            childAngleList.add(init);
            init = init + 20;
        }
        childAngleList.add(angle);
        childAngleList.add(angle-90);
        childAngleList.add(angle+90);
        childAngleList.add(angle+180);
        childAngleList.add(0);
        childAngleList.add(90);
        childAngleList.add(180);
        childAngleList.add(360);
        for (int inputAngle :childAngleList){
            LongLat neibourgh = current.nextPosition(inputAngle);
            if (canAddNodeToOpen(current,neibourgh)) {
                double g_cost = current.g_cost+0.00015;
                LongLat child = findNodeInOpen(neibourgh);
                if(child == null){
                    double heuristic = neibourgh.distanceTo(station);

                    if (neibourgh.closeTo(station)){
                        child = new LongLat(station.longitude,station.latitude);
                        child.parent = current;
                        child.g_cost = g_cost;
                        child.heuristic = heuristic;
                        OpenList.add(child);
                    }else {
                        child = new LongLat(neibourgh.longitude,neibourgh.latitude,current,g_cost,heuristic);
                        child.angle = inputAngle;

                        OpenList.add(child);
                    }
                }
                else if(child.g_cost>g_cost){
                    child.g_cost = g_cost;
                    child.parent = current;
                    OpenList.add(child);
                }
            }
        }
    }

    private void getNeiborghThree(int angle,LongLat current,LongLat station){
        ArrayList<Integer> childAngleList = new ArrayList<>();
        int init = 180;
        while (init<=270){
            childAngleList.add(init);
            init = init + 20;
        }
        childAngleList.add(angle);
        childAngleList.add(angle-90);
        childAngleList.add(angle+90);
        childAngleList.add(angle-180);;
        childAngleList.add(0);
        childAngleList.add(90);
        childAngleList.add(180);
        childAngleList.add(360);
        for (int inputAngle :childAngleList){
            LongLat neibourgh = current.nextPosition(inputAngle);
            if (canAddNodeToOpen(current,neibourgh)) {
                double g_cost = current.g_cost+0.00015;
                LongLat child = findNodeInOpen(neibourgh);
                if(child == null){
                    double heuristic = neibourgh.distanceTo(station);

                    if (neibourgh.closeTo(station)){
                        child = new LongLat(station.longitude,station.latitude);
                        child.parent = current;
                        child.g_cost = g_cost;
                        child.heuristic = heuristic;
                        OpenList.add(child);
                    }else {
                        child = new LongLat(neibourgh.longitude,neibourgh.latitude,current,g_cost,heuristic);
                        child.angle = inputAngle;

                        OpenList.add(child);
                    }
                }
                else if(child.g_cost>g_cost){
                    child.g_cost = g_cost;
                    child.parent = current;
                    OpenList.add(child);
                }
            }
        }
    }

    private void getNeiborghFour(int angle,LongLat current,LongLat station){
        ArrayList<Integer> childAngleList = new ArrayList<>();
        int init = 270;
        while (init<=360){
            childAngleList.add(init);
            init = init + 20;
        }
        childAngleList.add(angle);
        childAngleList.add(angle-90);
        childAngleList.add(angle-180);
        childAngleList.add(angle-270);;
        childAngleList.add(0);
        childAngleList.add(90);
        childAngleList.add(180);
        childAngleList.add(360);
        for (int inputAngle :childAngleList){
            LongLat neibourgh = current.nextPosition(inputAngle);
            if (canAddNodeToOpen(current,neibourgh)) {
                double g_cost = current.g_cost+0.00015;
                LongLat child = findNodeInOpen(neibourgh);
                if(child == null){
                    double heuristic = neibourgh.distanceTo(station);

                    if (neibourgh.closeTo(station)){
                        child = new LongLat(station.longitude,station.latitude);
                        child.parent = current;
                        child.g_cost = g_cost;
                        child.heuristic = heuristic;
                        OpenList.add(child);
                    }else {
                        child = new LongLat(neibourgh.longitude,neibourgh.latitude,current,g_cost,heuristic);
                        child.angle = inputAngle;

                        OpenList.add(child);
                    }
                }
                else if(child.g_cost>g_cost){
                    child.g_cost = g_cost;
                    child.parent = current;
                    OpenList.add(child);
                }
            }
        }
    }


    public void getNeiborghLongLats(LongLat current,LongLat station) {
        int angle = calAnagle(current,station);
        if(angle>=0&&angle<=90){
            getNeiborghOne(angle,current,station);
        }
        else if(angle>=90&&angle<=180){
            getNeiborghTwo(angle,current,station);
        }
        else if(angle>=180&&angle<=270){
            getNeiborghThree(angle,current,station);
        }
        else if (angle>=270&&angle<=360){
            getNeiborghFour(angle,current,station);
        }
    }


    public void addPath(ArrayList<Point> path,LongLat longLat){
        if (longLat == null) return;
        System.out.println("Total cost" + longLat.g_cost);
        while (longLat != null){
            Point point = Point.fromLngLat(longLat.longitude, longLat.latitude);
            path.add(point);
            moves = moves+1;
            longLat = longLat.parent;
        }
    }

    public ArrayList<Point> reverse(ArrayList<Point> list) {
        if(list.size() > 1) {
            Point point = list.remove(0);
            reverse(list);
            list.add(point);
        }
        return list;
    }

    /***
     * find the avalible landmark at current position

     */
    public ArrayList<LongLat> getLandmarks(LongLat current){
        ArrayList<LongLat> landmarks = new ArrayList<>();

        if(checkInNoFlyZone(current,landmark1)!=true&& current.closeTo(landmark1)==false){
            landmarks.add(landmark1);
        }
        if(checkInNoFlyZone(current,landmark2)!=true&& current.closeTo(landmark2)==false){
            landmarks.add(landmark2);
        }
        if(checkInNoFlyZone(current,landmark3)!=true&& current.closeTo(landmark3)==false){
            landmarks.add(landmark3);
        }
        if(checkInNoFlyZone(current,landmark4)!=true&& current.closeTo(landmark4)==false){
            landmarks.add(landmark4);
        }
        if(checkInNoFlyZone(current,landmark5)!=true&& current.closeTo(landmark5)==false){
            landmarks.add(landmark5);
        }
        if(checkInNoFlyZone(current,landmark6)!=true&& current.closeTo(landmark6)==false){
            landmarks.add(landmark6);
        }
        return landmarks;
    }

    private LongLat getCloestLandmark(ArrayList<LongLat> landmarks,LongLat current,LongLat destination){
        LongLat closestLandmark = null;
        for (LongLat landmark:landmarks){
            if (closestLandmark==null){
                closestLandmark = landmark;
            }else {
                double cost = current.distanceTo(landmark)+landmark.distanceTo(destination);
                double preCost = current.distanceTo(closestLandmark)+closestLandmark.distanceTo(destination);
                if(cost<preCost){
                    closestLandmark = landmark;
                }
            }

        }
        return closestLandmark;
    }



    public String startAstar() throws SQLException {
        ArrayList<LongLat> path = getDroneFlightPathList();
        path.add(path.size(),ApptonTower);
        OpenList.clear();
        CloseList.clear();

        for (LongLat station:path){
            LongLat current = new LongLat(drone.longitude,drone.latitude);
            while (checkInNoFlyZone(station,current)==true){
                OpenList.add(current);
                LongLat cloestLandmark = getCloestLandmark(getLandmarks(current),current,station);
                oneAstar(cloestLandmark);
                current = new LongLat(drone.longitude,drone.latitude);
            }
            OpenList.clear();
            OpenList.add(current);
            oneAstar(station);
        }

//        LongLat station = path.get(8);
//        LongLat current = new LongLat(path.get(7).longitude,path.get(7).latitude);
////        LongLat cloestLandmark = getCloestLandmark(getLandmarks(current),current,station);
//        while (checkInNoFlyZone(station,current)==true){
//            OpenList.add(current);
//            LongLat cloestLandmark = getCloestLandmark(getLandmarks(current),current,station);
//            oneAstar(cloestLandmark);
//            current = new LongLat(drone.longitude,drone.latitude);
//        }
//        OpenList.clear();
//        OpenList.add(current);
//        oneAstar(station);


        LineString line = LineString.fromLngLats(RealFlightpath);
        Geometry geometry = (Geometry) line;
        Feature feature = Feature.fromGeometry(geometry);
        FeatureCollection featureCollection = FeatureCollection.fromFeature(feature);
        String jsonString = featureCollection.toJson();
        System.out.println(moves);
        return jsonString;
    }


    ArrayList<Point> RealFlightpath = new ArrayList<>();


    public void oneAstar(LongLat station) throws SQLException{
        ArrayList<LongLat> path = getDroneFlightPathList();
        ArrayList<Point> flightPath = new ArrayList<>();
        while (!OpenList.isEmpty()){
            LongLat current = OpenList.poll();
            System.out.println(current.distanceTo(station));
            CloseList.add(current);
            getNeiborghLongLats(current,station);

            if(isCoordInClose(current)&&current.closeTo(station)){
                addPath(flightPath,current);
                flightPath = reverse(flightPath);
                RealFlightpath.addAll(flightPath);
                drone = current;
                OpenList.clear();
                CloseList.clear();
            }
        }
    }
}





    //





