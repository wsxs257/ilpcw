package uk.ac.ed.inf;
import java.sql.*;
import java.util.ArrayList;

public class Orders {
    String port;
    String date;

    Orders(String date,String port){
        this.date = date;
        this.port = port;
    }

    //get data for that day
    ArrayList<String> orderNumberList = new ArrayList<>();
    ArrayList<String> customerList = new ArrayList<>();
    ArrayList<String> deliverToList = new ArrayList<>();
    public void getOrders() throws SQLException {
        try {
            Connection conn = DriverManager.getConnection("jdbc:derby://localhost:"+port+"/derbyDB");
            final String ordersQuery =
                    "select * from orders where deliveryDate = (?)";
            PreparedStatement psOrdersQuery =
                    conn.prepareStatement(ordersQuery);
            psOrdersQuery.setString(1,date);
// Search for the orders on that date and add them to a list
            ResultSet rs = psOrdersQuery.executeQuery();
            while (rs.next()) {
                String orderNumber = rs.getString("orderNo");
                orderNumberList.add(orderNumber);
                String customer = rs.getString("customer");
                customerList.add(customer);
                String deliverTo = rs.getString("deliverTo");
                deliverToList.add(deliverTo);
            }
        }catch (java.sql.SQLException e){
            e.printStackTrace();
        }
    }

    //get the order details for one order number
    public ArrayList<String> getOrderDetails(String orderNo)throws SQLException{
        ArrayList<String> itemList = new ArrayList<>();
        try {
            Connection conn = DriverManager.getConnection("jdbc:derby://localhost:"+port+"/"+"derbyDB");
            final String orderDetailsQuery =
                    "select * from orderDetails where orderNo =(?)";
            PreparedStatement psOrderDetailQuery =
                    conn.prepareStatement(orderDetailsQuery);
            psOrderDetailQuery.setString(1, orderNo);
            ResultSet rs = psOrderDetailQuery.executeQuery();
            while (rs.next()) {
                String item = rs.getString("item");
                itemList.add(item);
            }
        }catch (Exception e){
            throw new java.sql.SQLException();
        }
        return itemList;
    }
}