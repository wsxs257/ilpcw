package uk.ac.ed.inf;

import com.mapbox.geojson.*;

import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.io.IOException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;

public class Buildings {
    String port;


    Buildings(String port){
        this.port = port;
    }
    //creat the client;
    private static final HttpClient client = HttpClient.newHttpClient();

    public HttpRequest getNoFlyZoneRequest(){
        return HttpRequest.newBuilder().uri(URI.create("http://localhost:"+port+"/buildings/no-fly-zones.geojson.")).build();
    }

    public String getNoFlyZoneResponse(){
        String response_body = " ";
        try {
            HttpResponse<String> response = client.send(getNoFlyZoneRequest(), HttpResponse.BodyHandlers.ofString());
            if (response.statusCode() == 200){
                response_body = response.body();
            }
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
        return response_body;
    }

    public HttpRequest getLandmarkRequest(){
        return HttpRequest.newBuilder().uri(URI.create("http://localhost:"+port+"/buildings/landmarks.geojson.")).build();
    }

    public String getLandmarkResponse(){
        String response_body = " ";
        try {
            HttpResponse<String> response = client.send(getLandmarkRequest(), HttpResponse.BodyHandlers.ofString());
            if (response.statusCode() == 200){
                response_body = response.body();
            }
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
        return response_body;
    }

    public ArrayList<Line2D> getLine2DNoFlyZone(){
        String source = getNoFlyZoneResponse();
        FeatureCollection featureCollection = FeatureCollection.fromJson(source);
        List<Feature> features = featureCollection.features();
        ArrayList<Line2D> line2DArrayList = new ArrayList<>();
        for(Feature feature:features){
            Polygon polygon = (Polygon)feature.geometry();
            for(List<Point> listPoint:polygon.coordinates()){
                ArrayList<Point2D> point2DArrayList = new ArrayList<>();
                for (Point point:listPoint){
                    Point2D point2D = new Point2D.Double();
                    point2D.setLocation(point.coordinates().get(0),point.coordinates().get(1));
                    point2DArrayList.add(point2D);
                }
                for (int i = 0;i<point2DArrayList.size();i++){
                    if (i == point2DArrayList.size()-1){
                        Line2D line2D = new Line2D.Double();
                        line2D.setLine(point2DArrayList.get(i),point2DArrayList.get(0));
                        line2DArrayList.add(line2D);
                    }else {
                        Line2D line2D = new Line2D.Double();
                        line2D.setLine(point2DArrayList.get(i),point2DArrayList.get(i+1));
                        line2DArrayList.add(line2D);
                    }
                }
            }

        }
        return line2DArrayList;
    }


    public LongLat getLandMarkOne() {
        String source = getLandmarkResponse();
        FeatureCollection featureCollection = FeatureCollection.fromJson(source);
        List<Feature> features = featureCollection.features();
        Feature feature = features.get(0);
        Point point = (Point) feature.geometry();
        LongLat landmark1 = new LongLat(point.coordinates().get(0),point.coordinates().get(1));
        return landmark1;
    }

    public LongLat getLandMarkTwo() {
        String source = getLandmarkResponse();
        FeatureCollection featureCollection = FeatureCollection.fromJson(source);
        List<Feature> features = featureCollection.features();
        Feature feature = features.get(1);
        Point point = (Point) feature.geometry();
        LongLat landmark2 = new LongLat(point.coordinates().get(0),point.coordinates().get(1));
        return landmark2;
    }


    public LongLat getClosedLandMark(LongLat location){
        LongLat landmark;
        double distanceFromLandMarkOne = location.distanceTo(getLandMarkOne());
        double distanceFromLandMarkTwo = location.distanceTo(getLandMarkTwo());
        if (distanceFromLandMarkOne>distanceFromLandMarkTwo){
            landmark = getLandMarkOne();
        }else {
            landmark = getLandMarkTwo();
        }
        return landmark;
    }


//    public void
//
//    public LongLat getLandMark(LongLat current,LongLat destination){
//        LongLat bestLandmark;
//        double distanceFromLandMarkOne = current.distanceTo(landmark1)+landmark1.distanceTo(destination);
//        double distanceFromLandMarkTwo = current.distanceTo(landmark2)+landmark2.distanceTo(destination);
//        double distanceFromLandMarkThree = current.distanceTo(landmark3)+landmark3.distanceTo(destination);
//        double distanceFromLandMarkFour = current.distanceTo(landmark1)+landmark1.distanceTo(destination);
//        double distanceFromLandMarkFive = current.distanceTo(landmark1)+landmark1.distanceTo(destination);
//        double distanceFromLandMarkSix = current.distanceTo(landmark1)+landmark1.distanceTo(destination);
//
//        return bestLandmark;
//    }

}
