package uk.ac.ed.inf;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Ordetails {
    String orderNo;
    String deliveryDate;
    String customer;
    ArrayList<String> deliverFrom;
    String deliverTo;
    ArrayList<String> items;
    int cost;

    public ArrayList<Ordetails> makeDetailsList(String date,String dataPort,String webPort) throws SQLException {
        ArrayList<Ordetails> details = new ArrayList<Ordetails>();
        Menus menus = new Menus(webPort);
        Orders orders = new Orders(date,dataPort);
        orders.getOrders();
        for(int i = 0;i <orders.orderNumberList.size(); i ++){
            Ordetails ordetails = new Ordetails();
            ordetails.orderNo = orders.orderNumberList.get(i);
            ordetails.deliveryDate = orders.date;
            ordetails.customer = orders.customerList.get(i);
            ordetails.deliverTo = orders.deliverToList.get(i);
            ordetails.items = orders.getOrderDetails(orders.orderNumberList.get(i));
            ordetails.cost = menus.getDeliveryCost(orders.getOrderDetails(orders.orderNumberList.get(i)));
            ordetails.deliverFrom = menus.get3wordLocation(orders.getOrderDetails(orders.orderNumberList.get(i)));
            details.add(ordetails);
        }
        return details;
    }
}
