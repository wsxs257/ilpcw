package uk.ac.ed.inf;

import java.util.Comparator;

public class longlatComparator implements Comparator<LongLat> {

    @Override
    public int compare(LongLat o1, LongLat o2) {
        if(o1 == null&&o2 == null)return -1;
        if(o1.g_cost+o1.heuristic>o2.g_cost+o2.heuristic)
            return 1;
        else if(o1.g_cost+o1.heuristic<o2.g_cost+o2.heuristic)return -1;
        return 0;
    }
}
