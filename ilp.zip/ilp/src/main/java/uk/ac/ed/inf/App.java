package uk.ac.ed.inf;

import java.sql.SQLException;
import java.util.ArrayList;

/**
 * Hello world!
 *
 */
public class App {
    public static void main( String[] args ) throws SQLException {
//        Orders orders = new Orders("2022-04-11","1527");
//        orders.getOrders();
//        Ordetails ordetails = new Ordetails();
//        System.out.println(orders.orderNumberList);
//        System.out.println("---------------");
//        System.out.println(orders.getOrderDetails("406d9b98"));
//        System.out.println("---------------");
//        ArrayList<Ordetails> details = ordetails.makeDetailsList("2022-04-11","1527","9898");
//        details.sort(new costSorter());
//        System.out.println(details.get(0).cost);
//        System.out.println(details.get(1).cost);
//        System.out.println(details.get(2).cost);
//        System.out.println(details.get(3).cost);
//        System.out.println("---------------");
//        System.out.println(details.get(0).deliverFrom);
//        System.out.println(details.get(0).deliverTo);

        DroneFlightPath droneFlightPath = new DroneFlightPath("9898","1527","2023-12-31");

        System.out.println(droneFlightPath.startAstar());

    }
}
