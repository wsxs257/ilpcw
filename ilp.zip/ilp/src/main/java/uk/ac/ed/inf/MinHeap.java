package uk.ac.ed.inf;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MinHeap
{
    private final ArrayList<LongLat> queue = new ArrayList<>();
    private int endPnt = 0;
    private final Map<String, LongLat> index = new HashMap<>();

    public LongLat poll()
    {
        if (isEmpty())
        {
            return null;
        }

        LongLat head = queue.get(0);
        LongLat last = queue.get(endPnt - 1);
        queue.set(0, last);
        endPnt--;
        index.remove(getKey(head));

        topDown();

        return head;
    }

    public void clear(){
        if (endPnt != 0){
            queue.clear();
        }
    }

    public LongLat find(LongLat longLat)
    {
        return index.get(getKey(longLat));
    }

    public void add(LongLat data)
    {
        if (queue.size() > endPnt)
        {
            queue.set(endPnt, data);
        }
        else
        {
            queue.add(data);
        }
        endPnt++;

        index.put(getKey(data), data);

        bottomUp();
    }


    public boolean isEmpty()
    {
        return endPnt <= 0;
    }


    private String getKey(LongLat longLat)
    {
        return String.format("%d-%d", longLat.longitude, longLat.latitude);
    }


    private void topDown()
    {
        for (int cur = 0; cur < endPnt;)
        {
            int left  = 2 * cur + 1;
            int right = 2 * cur + 2;

            LongLat current = queue.get(cur);
            LongLat leafChild = left < endPnt ? queue.get(left) : null;
            LongLat rightChild = right < endPnt ? queue.get(right) : null;

            int next = -1;
            LongLat dn = current;
            if (leafChild != null && leafChild.getFcost() < dn.getFcost())
            {
                next = left;
                dn = leafChild;
            }
            if (rightChild != null && rightChild.getFcost() < rightChild.getFcost())
            {
                next = right;
                dn = rightChild;
            }

            if (next >= 0 && next < endPnt)
            {
                queue.set(next, current);
                queue.set(cur, dn);
                cur = next;
            }
            else
            {
                break;
            }
        }
    }

    private void bottomUp()
    {
        for (int cur = endPnt - 1; cur >= 0; )
        {
            int parent = (cur - 1) / 2;
            if (parent < 0)
            {
                break;
            }

            LongLat dc = queue.get(cur);
            LongLat dp = queue.get(parent);

            if (dc.getFcost() < dp.getFcost())
            {
                queue.set(parent, dc);
                queue.set(cur, dp);
                cur = parent;
            }
            else
            {
                break;
            }
        }
    }
}